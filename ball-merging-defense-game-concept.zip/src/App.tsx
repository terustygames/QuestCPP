import { useEffect, useRef, useState } from 'react';
import { Engine } from './game/engine';
import { initAudio, setMuted } from './game/audio';
import { GameStage } from './components/GameStage';
import { Header, Controls } from './components/Hud';
import { TitleOverlay, HelpOverlay, GameOverOverlay } from './components/Overlays';

export default function App() {
  // Движок живёт в ref: он меняется 60 раз в секунду, чтобы не ловить замыкания
  const engRef = useRef<Engine | null>(null);
  if (!engRef.current) engRef.current = new Engine();
  const g = engRef.current;

  const [, setFrame] = useState(0);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [muted, setMutedState] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  // Главный игровой цикл
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      const game = engRef.current!;
      const active = game.status === 'prep' || game.status === 'wave';
      if (active && !paused && !helpOpen) game.step(dt * speed);
      setFrame((f) => f + 1); // перерисовываем сцену
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [paused, speed, helpOpen]);

  // Горячие клавиши: пробел — режим, B — призвать, Enter — волна
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const game = engRef.current!;
      const active = game.status === 'prep' || game.status === 'wave';
      if (e.code === 'Space') {
        e.preventDefault();
        if (active) game.toggleMode();
      } else if (e.code === 'KeyB') {
        if (active) game.buyOrb();
      } else if (e.code === 'Enter') {
        if (game.status === 'prep') game.callWaveNow();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const startNew = () => {
    initAudio();
    const game = new Engine();
    engRef.current = game;
    game.startGame();
    setPaused(false);
    setHelpOpen(false);
  };

  const toggleMute = () => {
    setMutedState((m) => {
      setMuted(!m);
      return !m;
    });
  };

  const playing = g.status === 'prep' || g.status === 'wave';

  return (
    <div
      className="min-h-screen w-full overflow-x-hidden bg-[#05070e] text-slate-100"
      style={{
        backgroundImage:
          'radial-gradient(1000px 500px at 50% -10%, rgba(56,120,255,.13), transparent 60%), radial-gradient(800px 400px at 85% 110%, rgba(177,108,255,.10), transparent 60%)',
      }}
    >
      <div className="mx-auto max-w-[1100px] px-3 pb-8 pt-4 sm:px-4">
        <Header
          g={g}
          paused={paused}
          speed={speed}
          muted={muted}
          onPause={() => setPaused((p) => !p)}
          onSpeed={() => setSpeed((s) => (s === 1 ? 2 : 1))}
          onMute={toggleMute}
          onHelp={() => setHelpOpen(true)}
        />

        <div className="mt-3">
          <GameStage g={g} onCell={(i) => g.clickCell(i)} onSell={(i) => g.sellCell(i)} />
        </div>

        {playing && (
          <Controls
            g={g}
            onBuy={() => {
              initAudio();
              g.buyOrb();
            }}
            onToggleMode={() => {
              initAudio();
              g.toggleMode();
            }}
            onCallWave={() => g.callWaveNow()}
          />
        )}

        {paused && playing && (
          <div className="mt-3 text-center text-sm font-semibold text-amber-300">
            Пауза — нажми Play в шапке, чтобы продолжить
          </div>
        )}
      </div>

      {g.status === 'title' && <TitleOverlay onStart={startNew} />}
      {helpOpen && <HelpOverlay onClose={() => setHelpOpen(false)} />}
      {g.status === 'gameover' && <GameOverOverlay g={g} onRestart={startNew} />}
    </div>
  );
}
