import type { ReactNode } from 'react';
import {
  MousePointerClick,
  Flame,
  Asterisk,
  Layers,
  ShieldAlert,
  Play,
  RotateCcw,
  Skull,
  DoorOpen,
  Flag,
  X,
} from 'lucide-react';
import type { Engine } from '../game/engine';

const RULES = [
  {
    icon: <MousePointerClick size={18} />,
    color: 'text-cyan-300',
    title: 'Совмещение — основная атака',
    text: 'Кликни шарик, потом кликни соседний. Оба выпустят снаряды по врагам. Если типы разные, каждый выпустит по 2 снаряда. После выстрела шарик перезаряжается 1.6 сек.',
  },
  {
    icon: <Flame size={18} />,
    color: 'text-orange-400',
    title: 'Типы шариков',
    text: 'Огонь — 3 урона и осколки по рядом стоящим. Лёд — замедляет. Молния — бьёт цепью ещё одного врага. Яд — отравляет, урон течёт 4 секунды.',
  },
  {
    icon: <Asterisk size={18} />,
    color: 'text-violet-400',
    title: 'Шипастый шарик',
    text: 'При соединении лопается и пускает 4 иглы по сторонам. Игла лопает первый шарик на пути — тот успевает выстрелить с двойной силой. Игла лопнет другой шипастый — будет цепная реакция. Цепь из 3+ взрывов даёт бонусную эссенцию.',
  },
  {
    icon: <Layers size={18} />,
    color: 'text-amber-300',
    title: 'Накопление',
    text: 'Включи режим накопления (пробел). Теперь одинаковые шарики сливаются в один: ×2, ×3 и выше. Вернись в совмещение — все заряженные шарики лопнут и выпустят удвоенные залпы. Риск: пока копишь, стрелять нельзя.',
  },
  {
    icon: <ShieldAlert size={18} />,
    color: 'text-rose-400',
    title: 'Задача',
    text: 'Враги идут по кругу к выходу. Дошедший забирает 1 жизнь. Каждая 5-я волна — босс, он забирает 5. Потеряешь все жизни — оборона пала.',
  },
];

function RulesList() {
  return (
    <div className="space-y-3">
      {RULES.map((r) => (
        <div key={r.title} className="flex gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3.5">
          <div className={`mt-0.5 shrink-0 ${r.color}`}>{r.icon}</div>
          <div>
            <div className="text-sm font-bold text-slate-100">{r.title}</div>
            <div className="mt-0.5 text-[13px] leading-relaxed text-slate-400">{r.text}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#04060d]/85 p-4 backdrop-blur-sm">
      <div className="my-8 w-full max-w-2xl rounded-3xl border border-white/10 bg-gradient-to-b from-slate-900/95 to-slate-950/95 p-6 shadow-2xl sm:p-9">
        {children}
      </div>
    </div>
  );
}

export function TitleOverlay({ onStart }: { onStart: () => void }) {
  return (
    <Shell>
      <div className="font-display bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-center text-4xl font-black tracking-wide text-transparent sm:text-5xl">
        ОРБИТАЛЬ
      </div>
      <p className="mt-2 text-center text-sm text-slate-400">
        Соединяй шарики — они стреляют. Лопай шипастые — строй цепные реакции.
        Копи заряды — устраивай детонацию. Не пусти врагов к выходу.
      </p>
      <div className="mt-6">
        <RulesList />
      </div>
      <button
        onClick={onStart}
        className="mx-auto mt-7 flex items-center gap-2.5 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 px-8 py-3.5 text-lg font-bold text-slate-950 shadow-lg shadow-cyan-500/30 transition-all hover:scale-105 hover:shadow-cyan-400/50 active:scale-95"
      >
        <Play size={20} strokeWidth={3} />
        Начать игру
      </button>
    </Shell>
  );
}

export function HelpOverlay({ onClose }: { onClose: () => void }) {
  return (
    <Shell>
      <div className="flex items-center justify-between">
        <div className="font-display text-2xl font-bold text-slate-100">Как играть</div>
        <button
          onClick={onClose}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-slate-400 transition hover:text-white"
        >
          <X size={16} />
        </button>
      </div>
      <div className="mt-5">
        <RulesList />
      </div>
      <button
        onClick={onClose}
        className="mx-auto mt-6 flex items-center gap-2 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 px-7 py-3 font-bold text-slate-950 transition-all hover:scale-105 active:scale-95"
      >
        <Play size={18} strokeWidth={3} />
        Продолжить
      </button>
    </Shell>
  );
}

export function GameOverOverlay({ g, onRestart }: { g: Engine; onRestart: () => void }) {
  const stats = [
    { icon: <Flag size={16} className="text-amber-300" />, label: 'Дошёл до волны', value: g.wave },
    { icon: <Skull size={16} className="text-slate-300" />, label: 'Убито врагов', value: g.kills },
    { icon: <DoorOpen size={16} className="text-rose-400" />, label: 'Пропущено', value: g.leaked },
    {
      icon: <Asterisk size={16} className="text-violet-400" />,
      label: 'Лучшая цепь',
      value: `×${g.maxChain}`,
    },
  ];
  return (
    <Shell>
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-rose-500/30 bg-rose-500/10 text-rose-400">
        <Skull size={32} />
      </div>
      <div className="font-display mt-4 text-center text-3xl font-black text-slate-100">
        Оборона пала
      </div>
      <p className="mt-1 text-center text-sm text-slate-400">
        Враги прорвались к выходу. Попробуй другую тактику: больше шипастых в центре — больше цепных реакций.
      </p>
      <div className="mx-auto mt-6 grid max-w-md grid-cols-2 gap-2.5">
        {stats.map((s) => (
          <div
            key={s.label}
            className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] px-4 py-3"
          >
            {s.icon}
            <div>
              <div className="text-[11px] text-slate-500">{s.label}</div>
              <div className="text-lg font-extrabold tabular-nums text-slate-100">{s.value}</div>
            </div>
          </div>
        ))}
      </div>
      <button
        onClick={onRestart}
        className="mx-auto mt-7 flex items-center gap-2.5 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 px-8 py-3.5 text-lg font-bold text-slate-950 shadow-lg shadow-cyan-500/30 transition-all hover:scale-105 active:scale-95"
      >
        <RotateCcw size={19} strokeWidth={3} />
        Играть снова
      </button>
    </Shell>
  );
}
