import type { ReactNode } from 'react';
import {
  Heart,
  Gem,
  Skull,
  Flag,
  Pause,
  Play,
  Volume2,
  VolumeX,
  HelpCircle,
  Plus,
  Combine,
  Layers,
  Zap,
} from 'lucide-react';
import type { Engine } from '../game/engine';
import { CONFIG, TYPE_INFO, ORB_TYPES } from '../game/config';

function Chip({ icon, children }: { icon: ReactNode; children: ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-1.5 text-sm font-semibold tabular-nums">
      {icon}
      {children}
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
}: {
  children: ReactNode;
  onClick: () => void;
  title: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 transition hover:border-white/25 hover:text-white"
    >
      {children}
    </button>
  );
}

export function Header({
  g,
  paused,
  speed,
  muted,
  onPause,
  onSpeed,
  onMute,
  onHelp,
}: {
  g: Engine;
  paused: boolean;
  speed: number;
  muted: boolean;
  onPause: () => void;
  onSpeed: () => void;
  onMute: () => void;
  onHelp: () => void;
}) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="font-display bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-xl font-black tracking-wide text-transparent sm:text-2xl">
          ОРБИТАЛЬ
        </div>
        <span className="rounded border border-white/10 px-1.5 py-0.5 text-[10px] uppercase tracking-[0.2em] text-slate-500">
          прототип v0.1
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Chip icon={<Flag size={15} className="text-amber-300" />}>Волна {g.wave}</Chip>
        <Chip icon={<Heart size={15} className="text-rose-400" fill="currentColor" />}>{g.lives}</Chip>
        <Chip icon={<Gem size={15} className="text-cyan-300" />}>{g.essence}</Chip>
        {g.status === 'wave' && (
          <Chip icon={<Skull size={15} className="text-slate-300" />}>{g.enemiesLeft}</Chip>
        )}
        <div className="mx-1 hidden h-6 w-px bg-white/10 sm:block" />
        <IconBtn onClick={onPause} title={paused ? 'Продолжить' : 'Пауза'}>
          {paused ? <Play size={16} /> : <Pause size={16} />}
        </IconBtn>
        <IconBtn onClick={onSpeed} title="Скорость игры ×1 / ×2">
          <span className="text-[12px] font-extrabold">{speed}×</span>
        </IconBtn>
        <IconBtn onClick={onMute} title={muted ? 'Включить звук' : 'Выключить звук'}>
          {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </IconBtn>
        <IconBtn onClick={onHelp} title="Как играть">
          <HelpCircle size={16} />
        </IconBtn>
      </div>
    </header>
  );
}

export function Controls({
  g,
  onBuy,
  onToggleMode,
  onCallWave,
}: {
  g: Engine;
  onBuy: () => void;
  onToggleMode: () => void;
  onCallWave: () => void;
}) {
  const accum = g.mode === 'accumulate';
  return (
    <div className="mt-3 flex flex-wrap items-stretch justify-center gap-3">
      <button
        onClick={onBuy}
        className="group relative flex items-center gap-2.5 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 px-5 py-3 font-bold text-slate-950 shadow-lg shadow-cyan-500/25 transition-all hover:scale-[1.03] hover:shadow-cyan-400/40 active:scale-95"
      >
        <Plus size={20} strokeWidth={3} />
        Призвать шарик
        <span className="flex items-center gap-1 rounded-lg bg-black/25 px-2 py-0.5 text-sm">
          <Gem size={13} />
          {CONFIG.orbCost}
        </span>
        {g.essence < CONFIG.orbCost && (
          <span className="absolute inset-0 rounded-2xl bg-slate-950/55" />
        )}
      </button>

      <button
        onClick={onToggleMode}
        className={`flex items-center gap-3 rounded-2xl border px-5 py-2.5 text-left transition-all active:scale-95 ${
          accum
            ? 'border-amber-400/50 bg-amber-500/15 text-amber-200 shadow-lg shadow-amber-500/10 hover:bg-amber-500/25'
            : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20'
        }`}
      >
        {accum ? <Layers size={20} /> : <Combine size={20} />}
        <span className="leading-tight">
          <span className="block text-[10px] uppercase tracking-wider opacity-70">
            режим · пробел
          </span>
          <span className="block font-bold">{accum ? 'Накопление' : 'Совмещение'}</span>
          <span className="block text-[10px] font-normal opacity-60">
            {accum
              ? 'одинаковые сливаются в один шарик'
              : 'два соседних шарика стреляют во врагов'}
          </span>
        </span>
      </button>

      {g.status === 'prep' && (
        <button
          onClick={onCallWave}
          className="flex items-center gap-2 rounded-2xl border border-amber-400/40 bg-amber-500/10 px-4 py-2.5 font-semibold text-amber-300 transition-all hover:bg-amber-500/20 active:scale-95"
        >
          <Zap size={18} />
          Волну сейчас
          <span className="rounded-lg bg-black/30 px-1.5 py-0.5 text-sm">+{CONFIG.callBonus}</span>
        </button>
      )}

      <div className="basis-full text-center text-[11px] text-slate-500">
        ЛКМ — выбрать шарик · ЛКМ по соседу — действие · ПКМ — продать шарик · Пробел — сменить
        режим · B — призвать · Enter — вызвать волну
      </div>
      <div className="flex basis-full flex-wrap justify-center gap-x-4 gap-y-1">
        {ORB_TYPES.map((t) => (
          <span key={t} className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ background: TYPE_INFO[t].color, boxShadow: `0 0 6px ${TYPE_INFO[t].color}` }}
            />
            {TYPE_INFO[t].name} — {TYPE_INFO[t].desc}
          </span>
        ))}
      </div>
    </div>
  );
}
