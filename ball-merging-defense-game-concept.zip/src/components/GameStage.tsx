import { useEffect, useRef, useState } from 'react';
import { LogIn, LogOut } from 'lucide-react';
import {
  STAGE_W,
  STAGE_H,
  CELL,
  TRACK,
  LEAK_AT,
  CONFIG,
  cellXY,
  isAdj,
  pathPoint,
  TYPE_INFO,
} from '../game/config';
import type { Engine, OrbState } from '../game/engine';

const EXIT_POS = pathPoint(LEAK_AT);
const SPAWN_POS = pathPoint(0);

// Шипы вокруг шипастого шарика (и у босса)
function Spikes({ color = '#8b46ff', count = 12 }: { color?: string; count?: number }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className="absolute -inset-[26%] spin-slow pointer-events-none"
      style={{ filter: `drop-shadow(0 0 6px ${color})` }}
    >
      {Array.from({ length: count }).map((_, k) => (
        <polygon
          key={k}
          points="50,4 42,30 58,30"
          transform={`rotate(${(360 / count) * k} 50 50)`}
          fill={color}
        />
      ))}
    </svg>
  );
}

// Один шарик на сетке
function OrbView({ orb, now }: { orb: OrbState; now: number }) {
  const info = TYPE_INFO[orb.type];
  const cd = Math.max(0, orb.cdUntil - now);
  const cdPct = cd > 0 ? cd / CONFIG.cooldown : 0;
  const cls = `absolute inset-[8px] rounded-full${now - orb.bornAt < 0.25 ? ' anim-pop' : ''}${
    now - orb.pulse < 0.22 ? ' orb-pulse' : ''
  }`;
  return (
    <div
      className={cls}
      style={{
        background: `radial-gradient(circle at 34% 28%, rgba(255,255,255,.9) 0%, ${info.color} 32%, ${info.dark} 100%)`,
        boxShadow: `0 0 ${14 + orb.level * 4}px ${info.glow}0.55), inset 0 -6px 12px rgba(0,0,0,.45), inset 0 4px 8px rgba(255,255,255,.25)`,
      }}
    >
      {orb.type === 'spiky' && <Spikes />}
      {orb.level > 1 && (
        <div
          className="absolute inset-[9px] rounded-full pointer-events-none"
          style={{ boxShadow: `inset 0 0 0 ${Math.min(6, orb.level + 1)}px ${info.glow}0.4)` }}
        />
      )}
      {cd > 0 && (
        <div
          className="absolute inset-0 rounded-full"
          style={{ background: `conic-gradient(rgba(3,7,18,.82) ${cdPct * 360}deg, transparent 0deg)` }}
        />
      )}
      {orb.level > 1 && (
        <div className="absolute -top-1.5 -right-1.5 z-10 rounded-full border border-white/30 bg-black/75 px-1.5 py-px text-[11px] font-extrabold text-white">
          ×{orb.level}
        </div>
      )}
    </div>
  );
}

export function GameStage({
  g,
  onCell,
  onSell,
}: {
  g: Engine;
  onCell: (i: number) => void;
  onSell: (i: number) => void;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const update = () => setScale(Math.min(1, el.clientWidth / STAGE_W));
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const shakeX = g.now < g.hurtUntil ? Math.sin(g.now * 90) * 5 : 0;
  const hurt = g.now < g.hurtUntil;
  const detFlash = g.now < g.detonateFlashUntil;

  const hint =
    g.mode === 'accumulate'
      ? 'НАКОПЛЕНИЕ: сливай одинаковые шарики. Вернись в совмещение — все заряженные (×2+) лопнут залпом.'
      : g.status === 'prep'
        ? 'Подготовка: призывай шарики (кнопка внизу) и расставляй пары. Шипастый лопает соседей иглами.'
        : 'Кликни шарик, затем соседний — оба выстрелят. Разные типы дают по 2 снаряда каждый.';

  return (
    <div ref={wrap} className="w-full select-none" style={{ height: STAGE_H * scale }}>
      <div
        className="relative origin-top-left overflow-hidden rounded-3xl border border-white/10"
        style={{
          width: STAGE_W,
          height: STAGE_H,
          transform: `scale(${scale}) translateX(${shakeX}px)`,
          background:
            'radial-gradient(700px 400px at 50% 45%, rgba(30,50,90,.5), rgba(5,8,16,.9)), #070b16',
        }}
      >
        {/* декоративная сетка-фон */}
        <div
          className="absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(80,110,180,.07) 1px, transparent 1px), linear-gradient(90deg, rgba(80,110,180,.07) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />

        {/* трасса */}
        <svg className="absolute inset-0" width={STAGE_W} height={STAGE_H}>
          <rect
            x={TRACK.x0}
            y={TRACK.y0}
            width={TRACK.x1 - TRACK.x0}
            height={TRACK.y1 - TRACK.y0}
            rx={TRACK.r}
            fill="none"
            stroke="#0e1626"
            strokeWidth={36}
          />
          <rect
            x={TRACK.x0}
            y={TRACK.y0}
            width={TRACK.x1 - TRACK.x0}
            height={TRACK.y1 - TRACK.y0}
            rx={TRACK.r}
            fill="none"
            stroke="#1d2c49"
            strokeWidth={30}
          />
          <rect
            x={TRACK.x0}
            y={TRACK.y0}
            width={TRACK.x1 - TRACK.x0}
            height={TRACK.y1 - TRACK.y0}
            rx={TRACK.r}
            fill="none"
            stroke="rgba(125,170,255,.28)"
            strokeWidth={2}
            strokeDasharray="10 14"
            className="track-dash"
          />
        </svg>

        {/* старт и выход */}
        <div
          className="absolute z-20 h-3.5 w-3.5 rounded-full beacon"
          style={{
            left: SPAWN_POS.x - 7,
            top: SPAWN_POS.y - 7,
            background: '#22c55e',
            ['--bc' as string]: 'rgba(34,197,94,.55)',
          }}
        />
        <div
          className="absolute z-20 flex items-center gap-1 text-[10px] font-bold tracking-widest text-emerald-300"
          style={{ left: SPAWN_POS.x + 12, top: SPAWN_POS.y - 30 }}
        >
          <LogIn size={12} /> СТАРТ
        </div>
        <div
          className="absolute z-20 h-3.5 w-3.5 rounded-full beacon"
          style={{
            left: EXIT_POS.x - 7,
            top: EXIT_POS.y - 7,
            background: '#ef4444',
            ['--bc' as string]: 'rgba(239,68,68,.55)',
          }}
        />
        <div
          className="absolute z-20 flex items-center gap-1 text-[10px] font-bold tracking-widest text-rose-300"
          style={{ left: EXIT_POS.x - 62, top: EXIT_POS.y + 16 }}
        >
          <LogOut size={12} /> ВЫХОД
        </div>

        {/* клетки с шариками */}
        {g.grid.map((orb, i) => {
          const { x, y } = cellXY(i);
          const selected = g.sel === i;
          const canLink = g.sel !== null && g.sel !== i && !!orb && isAdj(g.sel, i);
          const shaking = g.shakeCell === i && g.now < g.shakeUntil;
          return (
            <div
              key={i}
              onClick={() => onCell(i)}
              onContextMenu={(e) => {
                e.preventDefault();
                onSell(i);
              }}
              className={`absolute z-10 cursor-pointer${shaking ? ' cell-shake' : ''}`}
              style={{ left: x, top: y, width: CELL, height: CELL }}
            >
              <div
                className={`absolute inset-0 rounded-2xl border transition-colors ${
                  orb
                    ? 'border-white/10 bg-white/[0.03]'
                    : 'border-dashed border-white/10 bg-white/[0.015] hover:border-cyan-300/40 hover:bg-cyan-300/[0.04]'
                }`}
              />
              {canLink && <div className="can-link absolute inset-0 rounded-2xl" />}
              {selected && <div className="sel-ring absolute -inset-1" />}
              {orb && <OrbView orb={orb} now={g.now} />}
            </div>
          );
        })}

        {/* враги */}
        {g.enemies.map((e) => {
          const pos = pathPoint(e.p);
          const wob = Math.sin(e.id * 1.7 + e.p * 0.02) * 5;
          const x = pos.x + -pos.ty * wob;
          const y = pos.y + pos.tx * wob;
          const slowed = g.now < e.slowUntil;
          const poisoned = e.dots.length > 0;
          const flash = g.now < e.flashUntil;
          const hpPct = Math.max(0, e.hp / e.maxHp);
          return (
            <div key={e.id} className="absolute z-20" style={{ left: x - e.radius, top: y - e.radius - 7 }}>
              <div
                className="relative rounded-full"
                style={{
                  width: e.radius * 2,
                  height: e.radius * 2,
                  marginTop: 7,
                  background: e.boss
                    ? 'radial-gradient(circle at 34% 30%, #d8b4fe, #7e22ce 70%, #3b0764)'
                    : 'radial-gradient(circle at 34% 30%, #cbd5e1, #64748b 70%, #1e293b)',
                  boxShadow: `0 0 12px ${e.boss ? 'rgba(192,132,252,.5)' : 'rgba(148,163,184,.3)'}${
                    slowed ? ', 0 0 18px rgba(70,200,255,.85)' : ''
                  }${poisoned ? ', 0 0 18px rgba(74,222,128,.85)' : ''}`,
                  filter: flash ? 'brightness(2.2)' : 'none',
                }}
              >
                <div className="absolute rounded-full bg-black/80" style={{ width: 4, height: 4, left: '30%', top: '38%' }} />
                <div className="absolute rounded-full bg-black/80" style={{ width: 4, height: 4, left: '60%', top: '38%' }} />
              </div>
              <div
                className="absolute left-1/2 h-1 -translate-x-1/2 overflow-hidden rounded-full bg-black/60"
                style={{ width: e.boss ? 46 : 28, top: 0 }}
              >
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${hpPct * 100}%`,
                    background: hpPct > 0.5 ? '#4ade80' : hpPct > 0.25 ? '#facc15' : '#ef4444',
                  }}
                />
              </div>
            </div>
          );
        })}

        {/* иглы */}
        {g.needles.map((n) => (
          <div
            key={n.id}
            className="absolute z-30"
            style={{
              left: n.x - 14,
              top: n.y - 2,
              width: 28,
              height: 4,
              borderRadius: 2,
              background: 'linear-gradient(90deg, rgba(233,213,255,0), #e9d5ff 40%, #a855f7)',
              boxShadow: '0 0 8px rgba(168,85,247,.9)',
              transform: `rotate(${n.ang}rad)`,
            }}
          />
        ))}

        {/* снаряды со шлейфом */}
        {g.projs.map((p) => {
          const info = TYPE_INFO[p.kind];
          const sp = Math.hypot(p.vx, p.vy) || 1;
          const nx = -p.vy / sp;
          const ny = p.vx / sp;
          const off = Math.sin(p.age * 9 + p.seed) * 8;
          const x = p.x + nx * off;
          const y = p.y + ny * off;
          return (
            <div key={p.id}>
              {p.trail.slice(0, 4).map((t, k) => (
                <div
                  key={k}
                  className="absolute z-30 rounded-full"
                  style={{
                    left: t.x - (8 - k * 1.5) / 2,
                    top: t.y - (8 - k * 1.5) / 2,
                    width: 8 - k * 1.5,
                    height: 8 - k * 1.5,
                    background: info.color,
                    opacity: 0.26 - k * 0.055,
                  }}
                />
              ))}
              <div
                className="absolute z-40 rounded-full"
                style={{
                  left: x - 5,
                  top: y - 5,
                  width: 10,
                  height: 10,
                  background: `radial-gradient(circle at 35% 30%, #ffffff, ${info.color} 60%, ${info.dark})`,
                  boxShadow: `0 0 10px ${info.glow}0.9)`,
                }}
              />
            </div>
          );
        })}

        {/* частицы */}
        {g.parts.map((pt) => {
          const t = 1 - pt.life / pt.maxLife;
          if (pt.kind === 'spark')
            return (
              <div
                key={pt.id}
                className="absolute z-50 rounded-full"
                style={{
                  left: pt.x - pt.size / 2,
                  top: pt.y - pt.size / 2,
                  width: pt.size,
                  height: pt.size,
                  background: pt.color,
                  opacity: pt.life / pt.maxLife,
                }}
              />
            );
          if (pt.kind === 'ring') {
            const s = 10 + pt.size * t;
            return (
              <div
                key={pt.id}
                className="absolute z-50 rounded-full border-2"
                style={{
                  left: pt.x - s / 2,
                  top: pt.y - s / 2,
                  width: s,
                  height: s,
                  borderColor: pt.color,
                  opacity: 1 - t,
                }}
              />
            );
          }
          if (pt.kind === 'text')
            return (
              <div
                key={pt.id}
                className="pointer-events-none absolute z-50 font-extrabold"
                style={{
                  left: pt.x,
                  top: pt.y,
                  transform: `translate(-50%,-50%) translateY(${-26 * t}px)`,
                  color: pt.color,
                  fontSize: pt.size,
                  opacity: 1 - t,
                  textShadow: '0 2px 6px rgba(0,0,0,.75)',
                }}
              >
                {pt.text}
              </div>
            );
          const dx = pt.x2 - pt.x;
          const dy = pt.y2 - pt.y;
          const len = Math.hypot(dx, dy);
          const ang = Math.atan2(dy, dx);
          return (
            <div
              key={pt.id}
              className="absolute z-50"
              style={{
                left: pt.x,
                top: pt.y,
                width: len,
                height: 3,
                transformOrigin: '0 50%',
                transform: `rotate(${ang}rad) translateY(-1.5px)`,
                background: `linear-gradient(90deg, ${pt.color}, transparent)`,
                boxShadow: `0 0 8px ${pt.color}`,
                opacity: 1 - t,
              }}
            />
          );
        })}

        {/* вспышка детонации */}
        {detFlash && (
          <div
            className="pointer-events-none absolute inset-0 z-[55]"
            style={{
              background:
                'radial-gradient(600px 340px at 50% 50%, rgba(255,190,80,.28), transparent 70%)',
            }}
          />
        )}
        {/* красная рамка при утечке */}
        {hurt && (
          <div
            className="pointer-events-none absolute inset-0 z-[55] rounded-3xl"
            style={{ boxShadow: 'inset 0 0 90px rgba(239,68,68,.55)' }}
          />
        )}

        {/* верхняя строка статуса внутри поля */}
        <div className="absolute left-1/2 top-3 z-[58] -translate-x-1/2">
          {g.status === 'prep' && (
            <div className="rounded-xl border border-white/10 bg-slate-900/75 px-4 py-1.5 text-[13px] font-semibold text-slate-200 backdrop-blur-sm">
              Подготовка · волна <span className="text-amber-300">{g.wave}</span> через{' '}
              <span className="text-amber-300">{Math.max(0, Math.ceil(g.prepUntil - g.now))}</span> c
            </div>
          )}
          {g.status === 'wave' && (
            <div className="rounded-xl border border-white/10 bg-slate-900/75 px-4 py-1.5 text-[13px] font-semibold text-slate-200 backdrop-blur-sm">
              Волна <span className="text-amber-300">{g.wave}</span> · врагов осталось:{' '}
              <span className="text-rose-300">{g.enemiesLeft}</span>
            </div>
          )}
        </div>
        <div
          className={`absolute right-4 top-3 z-[58] rounded-xl border px-3 py-1.5 text-[12px] font-bold tracking-wide backdrop-blur-sm ${
            g.mode === 'accumulate'
              ? 'border-amber-400/40 bg-amber-500/15 text-amber-300'
              : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-300'
          }`}
        >
          {g.mode === 'accumulate' ? 'РЕЖИМ: НАКОПЛЕНИЕ' : 'РЕЖИМ: СОВМЕЩЕНИЕ'}
        </div>

        {/* большой баннер по центру верха поля */}
        {g.banner && g.now < g.bannerUntil && (
          <div className="pointer-events-none absolute left-1/2 top-[100px] z-[60] -translate-x-1/2">
            <div
              className="banner-in font-display whitespace-nowrap rounded-2xl border border-white/15 bg-slate-900/80 px-6 py-2 text-xl font-bold tracking-wide text-white backdrop-blur-sm"
              style={{ textShadow: '0 0 18px rgba(56,189,248,.8)' }}
            >
              {g.banner}
            </div>
          </div>
        )}

        {/* подсказка снизу */}
        <div className="pointer-events-none absolute bottom-2.5 left-1/2 z-[58] w-[92%] -translate-x-1/2 text-center text-[12.5px] text-slate-400">
          {hint}
        </div>

      </div>
    </div>
  );
}
